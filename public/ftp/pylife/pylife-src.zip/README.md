# pylife

A cellular automata simulator in Python

<p align="center">
  <img src="https://github.com/AlexOberhofer/pylife/raw/master/doc/conway.gif" />
</p>


Requires numpy and pysdl2

python3 pylife.py

Place SDL2.dll into directory of pylife.py if on Windows

License TBD
