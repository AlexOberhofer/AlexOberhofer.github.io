#ifndef PATH_H
#define PATH_H

char *path_search(char *name, char *mode, char *path);

#endif

