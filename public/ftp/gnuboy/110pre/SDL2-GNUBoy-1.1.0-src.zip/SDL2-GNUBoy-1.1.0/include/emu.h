#ifndef EMU_H
#define EMU_H

void emu_run();
void emu_reset();

#endif


