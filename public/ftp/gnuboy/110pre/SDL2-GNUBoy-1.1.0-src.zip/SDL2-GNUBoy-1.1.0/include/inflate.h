#ifndef INFLATE_H
#define INFLATE_H

int unzip (const unsigned char *data, long *p, void (* callback) (unsigned char d));

#endif

