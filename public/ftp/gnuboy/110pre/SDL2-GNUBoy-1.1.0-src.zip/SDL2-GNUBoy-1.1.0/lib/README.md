Library files go in this directory

SDL2 development headers will be installed here via sdl2-setup.sh
