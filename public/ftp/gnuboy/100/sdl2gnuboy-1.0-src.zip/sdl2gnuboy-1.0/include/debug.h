#ifndef DEBUG_H
#define DEBUG_H

void debug_disassemble(addr a, int c);

#endif

