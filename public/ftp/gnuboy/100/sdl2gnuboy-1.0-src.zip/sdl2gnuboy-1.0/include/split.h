#ifndef SPLIT_H
#define SPLIT_H

int splitline(char **argv, int max, char *line);

#endif

