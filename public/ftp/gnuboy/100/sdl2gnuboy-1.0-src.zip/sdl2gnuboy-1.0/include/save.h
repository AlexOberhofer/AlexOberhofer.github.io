#ifndef SAVE_H
#define SAVE_H

#include <stdio.h>

void savestate(FILE *f);
void loadstate(FILE *f);

#endif

