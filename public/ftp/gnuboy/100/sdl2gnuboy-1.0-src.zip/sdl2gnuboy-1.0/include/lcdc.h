#ifndef LCDC_H
#define LCDC_H

void lcdc_change(byte b);
void lcdc_trans();
void stat_write(byte b);
void stat_trigger();

#endif


